package edu.canberra.mobiletech.assignment.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import edu.canberra.mobiletech.assignment.EditMode
import edu.canberra.mobiletech.assignment.IntentExtras
import edu.canberra.mobiletech.assignment.data.local.ImageStorage
import edu.canberra.mobiletech.assignment.data.model.ReaderType
import edu.canberra.mobiletech.assignment.data.repo.AnalysisRepository
import edu.canberra.mobiletech.assignment.databinding.ActivityEditSaveBinding

/**
 * Activity 5: edit text, save to Firebase and image to app storage.
 */
class EditSaveActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditSaveBinding
    private lateinit var mode: String
    private lateinit var readerType: ReaderType
    private var recordId: String? = null
    private var imageFileName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditSaveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mode = intent.getStringExtra(IntentExtras.MODE) ?: EditMode.NEW
        readerType = ReaderType.fromName(intent.getStringExtra(IntentExtras.READER_TYPE))

        binding.inputReaderType.setText(ReaderType.displayName(readerType))

        if (mode == EditMode.EDIT) {
            recordId = intent.getStringExtra(IntentExtras.RECORD_ID)
            imageFileName = intent.getStringExtra(IntentExtras.IMAGE_FILE_NAME)
            binding.inputResult.setText(intent.getStringExtra(IntentExtras.RESULT_TEXT) ?: "")
            val name = imageFileName
            if (name != null) {
                val file = ImageStorage.getImageFile(this, name)
                if (file.exists()) {
                    binding.imagePreview.setImageURI(Uri.fromFile(file))
                }
            }
        } else {
            val uriStr = intent.getStringExtra(IntentExtras.IMAGE_URI)
            if (uriStr.isNullOrBlank()) {
                Toast.makeText(this, "Missing image", Toast.LENGTH_LONG).show()
                finish()
                return
            }
            binding.inputResult.setText(intent.getStringExtra(IntentExtras.RESULT_TEXT) ?: "")
            binding.imagePreview.setImageURI(Uri.parse(uriStr))
        }

        binding.btnSave.setOnClickListener { save() }
    }

    private fun save() {
        val text = binding.inputResult.text?.toString() ?: ""
        val repo = AnalysisRepository(applicationContext)

        if (mode == EditMode.NEW) {
            val uriStr = intent.getStringExtra(IntentExtras.IMAGE_URI) ?: return
            val uri = Uri.parse(uriStr)
            repo.saveNew(readerType, text, uri) { ok ->
                if (ok) {
                    goToList()
                } else {
                    Toast.makeText(this, "Save failed", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            val id = recordId ?: return
            repo.updateText(id, text) { ok ->
                if (ok) {
                    goToList()
                } else {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun goToList() {
        startActivity(
            Intent(this, AnalysisListActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
        )
        finish()
    }
}
