package edu.canberra.mobiletech.assignment

object IntentExtras {
    const val READER_TYPE = "reader_type"
    const val MODE = "mode"
    const val RECORD_ID = "record_id"
    const val RESULT_TEXT = "result_text"
    const val IMAGE_URI = "image_uri"
    const val IMAGE_FILE_NAME = "image_file_name"
}

object EditMode {
    const val NEW = "new"
    const val EDIT = "edit"
}
