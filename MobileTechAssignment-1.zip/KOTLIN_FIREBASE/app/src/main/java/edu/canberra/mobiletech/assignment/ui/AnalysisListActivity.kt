package edu.canberra.mobiletech.assignment.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.ValueEventListener
import edu.canberra.mobiletech.assignment.IntentExtras
import edu.canberra.mobiletech.assignment.data.model.AnalysisRecord
import edu.canberra.mobiletech.assignment.data.repo.AnalysisRepository
import edu.canberra.mobiletech.assignment.databinding.ActivityAnalysisListBinding
import edu.canberra.mobiletech.assignment.ui.adapter.AnalysisAdapter

/**
 * Activity 6: list from Firebase; images from local files; Add opens Activity 1.
 */
class AnalysisListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalysisListBinding
    private val repository by lazy { AnalysisRepository(applicationContext) }
    private var listener: ValueEventListener? = null

    private val adapter = AnalysisAdapter { record -> openDetail(record) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalysisListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.listView.adapter = adapter
        binding.listView.emptyView = binding.emptyView

        binding.btnAdd.setOnClickListener {
            startActivity(
                Intent(this, HomeActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        listener = repository.observeAll { records ->
            adapter.submit(records)
        }
    }

    override fun onStop() {
        super.onStop()
        listener?.let { repository.removeListener(it) }
        listener = null
    }

    private fun openDetail(record: AnalysisRecord) {
        val i = Intent(this, AnalysisDetailActivity::class.java).apply {
            putExtra(IntentExtras.RECORD_ID, record.id)
            putExtra(IntentExtras.READER_TYPE, record.readerType.name)
            putExtra(IntentExtras.RESULT_TEXT, record.resultText)
            putExtra(IntentExtras.IMAGE_FILE_NAME, record.imageFileName)
        }
        startActivity(i)
    }
}
