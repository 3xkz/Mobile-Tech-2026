package edu.canberra.mobiletech.assignment.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import edu.canberra.mobiletech.assignment.EditMode
import edu.canberra.mobiletech.assignment.IntentExtras
import edu.canberra.mobiletech.assignment.R
import edu.canberra.mobiletech.assignment.data.model.ReaderType
import edu.canberra.mobiletech.assignment.databinding.ActivityReaderBinding
import edu.canberra.mobiletech.assignment.ml.MlKitAnalyzer
import edu.canberra.mobiletech.assignment.ml.MlResultFormatter
import kotlinx.coroutines.launch
import java.io.File

/**
 * Activity 2: ML Kit with camera/gallery actions.
 */
class ReaderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReaderBinding
    private lateinit var readerType: ReaderType
    private var currentImageUri: Uri? = null
    private var resultText: String = ""
    private var pendingCameraUri: Uri? = null

    private val takePicture = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        pendingCameraUri = null
        if (success && uri != null) {
            onImagePicked(uri)
        }
    }

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchCameraCapture()
        }
    }

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { onImagePicked(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        readerType = ReaderType.fromName(intent.getStringExtra(IntentExtras.READER_TYPE))

        resetUiForReader()
        showPlaceholderImage()

        binding.btnCamera.setOnClickListener {
            openCamera()
        }
        binding.btnGallery.setOnClickListener {
            pickImage.launch("image/*")
        }

        binding.btnEdit.setOnClickListener {
            val uri = currentImageUri ?: return@setOnClickListener
            val i = Intent(this, EditSaveActivity::class.java).apply {
                putExtra(IntentExtras.MODE, EditMode.NEW)
                putExtra(IntentExtras.READER_TYPE, readerType.name)
                putExtra(IntentExtras.RESULT_TEXT, resultText)
                putExtra(IntentExtras.IMAGE_URI, uri.toString())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(i)
            finish()
        }
    }

    private fun resetUiForReader() {
        binding.titleMain.setText(R.string.reader_title_get_image)
        binding.subtitle.setText(R.string.reader_hint_actions)
        binding.btnEdit.visibility = View.GONE
        binding.btnEdit.isEnabled = false
    }

    private fun showPlaceholderImage() {
        val resId = when (readerType) {
            ReaderType.BARCODE -> R.drawable.barcode
            ReaderType.CONTENT -> R.drawable.content
            ReaderType.TEXT -> R.drawable.text
        }
        binding.imagePreview.setImageResource(resId)
        binding.imagePreview.scaleType = android.widget.ImageView.ScaleType.FIT_XY
        currentImageUri = null
    }

    private fun onImagePicked(uri: Uri) {
        val stable = copyToAppCache(uri)
        currentImageUri = stable
        binding.imagePreview.setImageURI(stable)
        binding.imagePreview.scaleType = android.widget.ImageView.ScaleType.FIT_XY
        binding.progress.visibility = View.VISIBLE
        binding.btnEdit.isEnabled = false
        binding.btnEdit.visibility = View.GONE

        binding.titleMain.text = ReaderType.displayName(readerType)
        binding.subtitle.text = ""

        lifecycleScope.launch {
            try {
                val lines = MlKitAnalyzer(this@ReaderActivity).analyzeLines(stable, readerType)
                resultText = MlResultFormatter.format(readerType, lines)
                binding.subtitle.text = resultText
                binding.btnEdit.isEnabled = true
                binding.btnEdit.visibility = View.VISIBLE
            } catch (e: Exception) {
                binding.subtitle.text = "Analysis error: ${e.message ?: "unknown"}"
            } finally {
                binding.progress.visibility = View.GONE
            }
        }
    }

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            launchCameraCapture()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchCameraCapture() {
        val dest = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            dest
        )
        pendingCameraUri = uri
        takePicture.launch(uri)
    }

    private fun copyToAppCache(source: Uri): Uri {
        val dest = File(cacheDir, "reader_working_${System.currentTimeMillis()}.jpg")
        contentResolver.openInputStream(source)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("Cannot read image")
        return FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            dest
        )
    }
}
