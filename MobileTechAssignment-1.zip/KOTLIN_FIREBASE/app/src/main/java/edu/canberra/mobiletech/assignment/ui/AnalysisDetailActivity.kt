package edu.canberra.mobiletech.assignment.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import edu.canberra.mobiletech.assignment.EditMode
import edu.canberra.mobiletech.assignment.IntentExtras
import edu.canberra.mobiletech.assignment.data.local.ImageStorage
import edu.canberra.mobiletech.assignment.data.model.ReaderType
import edu.canberra.mobiletech.assignment.data.repo.AnalysisRepository
import edu.canberra.mobiletech.assignment.databinding.ActivityAnalysisDetailBinding

/**
 * Activity 7: rubric — Cancel/Delete open Activity 6 explicitly.
 */
class AnalysisDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalysisDetailBinding
    private lateinit var recordId: String
    private lateinit var imageFileName: String
    private lateinit var readerType: ReaderType
    private lateinit var resultText: String

    private val repository by lazy { AnalysisRepository(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalysisDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recordId = intent.getStringExtra(IntentExtras.RECORD_ID) ?: run { finish(); return }
        imageFileName = intent.getStringExtra(IntentExtras.IMAGE_FILE_NAME) ?: run { finish(); return }
        readerType = ReaderType.fromName(intent.getStringExtra(IntentExtras.READER_TYPE))
        resultText = intent.getStringExtra(IntentExtras.RESULT_TEXT) ?: ""

        binding.textReader.text = ReaderType.displayName(readerType)
        binding.textResult.text = resultText

        val file = ImageStorage.getImageFile(this, imageFileName)
        if (file.exists()) {
            binding.imagePreview.setImageURI(Uri.fromFile(file))
        }

        binding.btnEdit.setOnClickListener {
            startActivity(
                Intent(this, EditSaveActivity::class.java).apply {
                    putExtra(IntentExtras.MODE, EditMode.EDIT)
                    putExtra(IntentExtras.RECORD_ID, recordId)
                    putExtra(IntentExtras.READER_TYPE, readerType.name)
                    putExtra(IntentExtras.RESULT_TEXT, resultText)
                    putExtra(IntentExtras.IMAGE_FILE_NAME, imageFileName)
                }
            )
        }

        binding.btnCancel.setOnClickListener {
            openActivity6()
        }

        binding.btnDelete.setOnClickListener {
            repository.delete(recordId, imageFileName) { ok ->
                if (ok) {
                    openActivity6()
                }
            }
        }
    }

    private fun openActivity6() {
        startActivity(
            Intent(this, AnalysisListActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
        )
        finish()
    }
}
