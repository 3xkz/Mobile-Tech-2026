package edu.canberra.mobiletech.assignment.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import edu.canberra.mobiletech.assignment.IntentExtras
import edu.canberra.mobiletech.assignment.data.model.ReaderType
import edu.canberra.mobiletech.assignment.databinding.ActivityHomeBinding

/**
 * Activity 1 (main).
 */
class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.imgBarcode.setOnClickListener {
            startReader(ReaderType.BARCODE)
        }
        binding.imgContent.setOnClickListener {
            startReader(ReaderType.CONTENT)
        }
        binding.imgText.setOnClickListener {
            startReader(ReaderType.TEXT)
        }
        binding.btnList.setOnClickListener {
            startActivity(Intent(this, AnalysisListActivity::class.java))
        }
    }

    private fun startReader(type: ReaderType) {
        val intent = Intent(this, ReaderActivity::class.java).apply {
            putExtra(IntentExtras.READER_TYPE, type.name)
        }
        startActivity(intent)
    }
}
