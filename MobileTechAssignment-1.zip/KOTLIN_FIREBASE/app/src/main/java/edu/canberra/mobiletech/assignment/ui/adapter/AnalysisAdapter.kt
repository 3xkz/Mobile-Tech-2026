package edu.canberra.mobiletech.assignment.ui.adapter

import android.net.Uri
import android.view.View
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.BaseAdapter
import androidx.core.content.ContextCompat
import edu.canberra.mobiletech.assignment.R
import edu.canberra.mobiletech.assignment.data.local.ImageStorage
import edu.canberra.mobiletech.assignment.data.model.AnalysisRecord
import edu.canberra.mobiletech.assignment.databinding.ItemAnalysisBinding
import java.io.File

class AnalysisAdapter(
    private val onClick: (AnalysisRecord) -> Unit
) : BaseAdapter() {

    private var items: List<AnalysisRecord> = emptyList()

    fun submit(list: List<AnalysisRecord>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size

    override fun getItem(position: Int): AnalysisRecord = items[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemAnalysisBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        } else {
            ItemAnalysisBinding.bind(convertView)
        }

        val record = getItem(position)
        binding.textPreview.text = record.resultText

        // Rubric: grey for odd rows (1st, 3rd, …), white for even rows (2nd, 4th, …)
        val bg = if (position % 2 == 0) R.color.list_row_odd else R.color.list_row_even
        binding.root.setBackgroundColor(ContextCompat.getColor(parent.context, bg))

        val file: File = ImageStorage.getImageFile(parent.context, record.imageFileName)
        if (file.exists()) {
            binding.thumb.setImageURI(Uri.fromFile(file))
        } else {
            binding.thumb.setImageDrawable(null)
        }

        binding.root.setOnClickListener { onClick(record) }
        return binding.root
    }
}
