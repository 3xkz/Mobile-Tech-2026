package edu.canberra.mobiletech.assignment.data.model

data class AnalysisRecord(
    val id: String,
    val readerType: ReaderType,
    val resultText: String,
    val imageFileName: String,
    val createdAt: Long = 0L
)
