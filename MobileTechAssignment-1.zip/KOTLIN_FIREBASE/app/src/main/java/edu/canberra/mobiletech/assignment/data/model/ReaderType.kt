package edu.canberra.mobiletech.assignment.data.model

enum class ReaderType {
    BARCODE,
    CONTENT,
    TEXT;

    companion object {
        fun fromName(name: String?): ReaderType =
            entries.find { it.name == name } ?: BARCODE

        fun displayName(type: ReaderType): String = when (type) {
            BARCODE -> "Barcode Reader"
            CONTENT -> "Content Reader"
            TEXT -> "Text Reader"
        }
    }
}
