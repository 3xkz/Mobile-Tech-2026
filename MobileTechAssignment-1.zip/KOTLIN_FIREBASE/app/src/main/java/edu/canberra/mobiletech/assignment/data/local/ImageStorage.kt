package edu.canberra.mobiletech.assignment.data.local

import android.content.Context
import android.net.Uri
import java.io.File

object ImageStorage {

    private fun imagesDir(context: Context): File =
        File(context.filesDir, "images").apply { mkdirs() }

    fun saveImageFromUri(context: Context, uri: Uri, fileName: String): String {
        val file = File(imagesDir(context), fileName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            file.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Could not read image")
        return file.absolutePath
    }

    fun getImageFile(context: Context, fileName: String): File =
        File(imagesDir(context), fileName)

    fun deleteImage(context: Context, fileName: String) {
        getImageFile(context, fileName).delete()
    }
}
