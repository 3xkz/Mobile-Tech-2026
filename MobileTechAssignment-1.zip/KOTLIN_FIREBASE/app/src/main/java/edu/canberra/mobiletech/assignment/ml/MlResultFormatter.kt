package edu.canberra.mobiletech.assignment.ml

import edu.canberra.mobiletech.assignment.data.model.ReaderType

/**
 * Rubric: ML Kit results must start with Detected barcode / Recognised image content / Extracted text
 * and use a numbered list.
 */
object MlResultFormatter {

    fun format(readerType: ReaderType, lines: List<String>): String {
        val header = when (readerType) {
            ReaderType.BARCODE -> "Detected barcode"
            ReaderType.CONTENT -> "Recognised image content"
            ReaderType.TEXT -> "Extracted text"
        }
        val body = if (lines.isEmpty()) {
            "1. (none)"
        } else {
            lines.mapIndexed { index, line -> "${index + 1}. $line" }.joinToString("\n")
        }
        return "$header:\n$body"
    }
}
