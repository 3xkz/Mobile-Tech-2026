package edu.canberra.mobiletech.assignment.ml

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import edu.canberra.mobiletech.assignment.data.model.ReaderType
import kotlinx.coroutines.tasks.await

class MlKitAnalyzer(private val context: Context) {

    private val barcodeScanner = BarcodeScanning.getClient()
    private val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    private val textRecognizer = TextRecognition.getClient(
        TextRecognizerOptions.Builder().build()
    )

    /**
     * Returns raw lines for [MlResultFormatter.format].
     */
    suspend fun analyzeLines(uri: Uri, type: ReaderType): List<String> {
        val image = InputImage.fromFilePath(context, uri)
        return when (type) {
            ReaderType.BARCODE -> {
                val codes = barcodeScanner.process(image).await()
                if (codes.isEmpty()) emptyList()
                else codes.mapNotNull { it.rawValue?.trim() }.filter { it.isNotEmpty() }
            }
            ReaderType.CONTENT -> {
                val labels = labeler.process(image).await()
                if (labels.isEmpty()) emptyList()
                else labels.take(12).map { label ->
                    "${label.text} (${(label.confidence * 100).toInt()}%)"
                }
            }
            ReaderType.TEXT -> {
                val result = textRecognizer.process(image).await()
                val raw = result.text.trim()
                if (raw.isEmpty()) emptyList()
                else raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                    .ifEmpty { listOf(raw) }
            }
        }
    }
}
