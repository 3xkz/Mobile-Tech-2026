package edu.canberra.mobiletech.assignment.data.repo

import android.content.Context
import android.net.Uri
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import edu.canberra.mobiletech.assignment.data.local.ImageStorage
import edu.canberra.mobiletech.assignment.data.model.AnalysisRecord
import edu.canberra.mobiletech.assignment.data.model.ReaderType

class AnalysisRepository(
    private val context: Context,
    database: FirebaseDatabase = FirebaseDatabase.getInstance()
) {
    private val analyses = database.reference.child("analyses")

    fun observeAll(onChange: (List<AnalysisRecord>) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull { snap -> parseRecord(snap) }
                    .sortedByDescending { it.createdAt }
                onChange(list)
            }

            override fun onCancelled(error: DatabaseError) {
                onChange(emptyList())
            }
        }
        analyses.addValueEventListener(listener)
        return listener
    }

    fun removeListener(listener: ValueEventListener) {
        analyses.removeEventListener(listener)
    }

    private fun parseRecord(snap: DataSnapshot): AnalysisRecord? {
        val id = snap.key ?: return null
        val readerType = ReaderType.fromName(snap.child("readerType").getValue(String::class.java))
        val resultText = snap.child("resultText").getValue(String::class.java) ?: ""
        val imageFileName = snap.child("imageFileName").getValue(String::class.java) ?: return null
        val createdAt = when (val v = snap.child("createdAt").value) {
            is Long -> v
            is Int -> v.toLong()
            is Double -> v.toLong()
            else -> 0L
        }
        return AnalysisRecord(id, readerType, resultText, imageFileName, createdAt)
    }

    fun saveNew(
        readerType: ReaderType,
        resultText: String,
        imageUri: Uri,
        onComplete: (Boolean) -> Unit
    ) {
        val key = analyses.push().key
        if (key == null) {
            onComplete(false)
            return
        }
        val fileName = "$key.jpg"
        try {
            ImageStorage.saveImageFromUri(context, imageUri, fileName)
        } catch (_: Exception) {
            onComplete(false)
            return
        }
        val data = mapOf(
            "readerType" to readerType.name,
            "resultText" to resultText,
            "imageFileName" to fileName,
            "createdAt" to System.currentTimeMillis()
        )
        analyses.child(key).setValue(data).addOnCompleteListener { onComplete(it.isSuccessful) }
    }

    fun updateText(recordId: String, resultText: String, onComplete: (Boolean) -> Unit) {
        analyses.child(recordId).child("resultText").setValue(resultText)
            .addOnCompleteListener { onComplete(it.isSuccessful) }
    }

    fun delete(recordId: String, imageFileName: String, onComplete: (Boolean) -> Unit) {
        analyses.child(recordId).removeValue().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                ImageStorage.deleteImage(context, imageFileName)
            }
            onComplete(task.isSuccessful)
        }
    }
}
